#!/bin/bash
# If using Maven
mvn clean install