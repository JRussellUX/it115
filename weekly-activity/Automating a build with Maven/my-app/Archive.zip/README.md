To run this program, in a terminal, run:
./build.sh
java -jar target/my-app-1.0-SNAPSHOT.jar
